<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/pages/email.blade.php */ ?>
Hi <strong><?php echo e($name); ?></strong>,

<p> Please verify your account by clicking on this liknk:</p>
<a href="<?php echo e($body); ?>">Click Me!</a>
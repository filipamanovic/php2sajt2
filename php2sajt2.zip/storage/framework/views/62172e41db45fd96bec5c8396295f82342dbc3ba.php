<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/components/single_product.blade.php */ ?>
<div class="col-lg-9" style="margin-top: -25px;">
    <div class="card mt-4">
         <img class="card-img-top img-fluid" src="<?php echo e(asset($product->src)); ?>" alt="<?php echo e($product->alt); ?>">
         <div class="card-body">
              <h3 class="card-title" style="color: #138496;"><?php echo e($product->naziv); ?></h3>
              <h4 style="color: #138496;">&euro; <?php echo e($product->cena); ?></h4>
              <p class="card-text"><?php echo e($product->opis); ?></p>
         </div>
         <div class="card-footer">
             <span class="float-left"><i class="fa fa-eye" aria-hidden="true"></i><?php echo e(' '.$product->pregledano); ?></span>
             <span class="float-right">Created at: <?php echo e(' '.date('d-m-Y', $product->datum)); ?></span>
         </div>
    </div>


            <div class="card card-outline-secondary my-4">
                <div class="card-header">
                    Product Reviews
                </div>
                <div class="card-body">
                    <?php if(count($comments) == 0): ?>
                        <?php echo e("There are currently no product reviews."); ?>

                    <?php else: ?>
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($item->text); ?></p>
                        <small class="text-muted">
                        Posted by <?php echo e($item->ime.' '.$item->prezime); ?> on <?php echo e(date('d-m-Y', $item->datum)); ?>

                        </small>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <hr>
                    <?php if(session()->has('user')): ?>
                        <a href="#" class="btn btn-success" data-toggle="modal" data-target="#exampleModal3">Leave a Review</a>
                        <?php $__env->startComponent('front.components.review_modal', ['product' => $product]); ?><?php echo $__env->renderComponent(); ?>
                    <?php else: ?>
                        You want to leave a comment? <a href="" data-toggle="modal" data-target="#exampleModal2"> Sing in!</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>




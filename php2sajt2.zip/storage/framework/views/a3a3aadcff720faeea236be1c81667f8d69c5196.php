<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/components/insert_product.blade.php */ ?>
<div class="col-lg-3 signup-form">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('productInsert')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h3>Add product</h3>
        <p></p>
        <div class="form-group">
            <label class="formaUnos">Product name:</label>
            <input type="text" class="form-control" name="productName" required="required">
        </div>
        <div class="form-group">
            <label class="formaUnos">Product description:</label>
            <textarea rows="6" class="form-control" name="productDesc" required="required"> </textarea>
        </div>
        <div class="form-group">
            <label class="formaUnos">Product price in &euro;:</label>
            <input type="text" class="form-control" name="productPrice" required="required">
        </div>
        <div class="form-group">
            <label class="formaUnos">Product picture:</label>
            <input type="file" class="form-control" name="productImage" required="required">
        </div>
        <div class="form-group">
            <label class="formaUnos">Product category:</label>
            <select class="form-control" name="productCategory">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->naziv); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label class="formaUnos">Product manufacturer:</label>
            <select class="form-control" name="productManufacturer">
                <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->naziv); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-lg btn-block" name="addProduct">Add product</button>
        </div>
    </form>
</div>
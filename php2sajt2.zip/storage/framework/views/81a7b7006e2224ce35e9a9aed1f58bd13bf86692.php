<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/role/insert_modal.blade.php */ ?>
<div class="modal fade" id="adminRoleInsert" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">New User</h3>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('user.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <p></p>
                    <div class="form-group">
                        <input type="text" class="form-control" name="role_name" placeholder="Role name" required="required">
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success" name="inComm">Add new user</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/components/sort_component.blade.php */ ?>
<div class="col-lg-3">
    <form action="<?php echo e(route('sortProduct')); ?>" method="get">
        <h3 class="my-4">Sort products:</h3>
        <p class="hint-text">Choose category:</p>
        <select class="form-control" name="category_id">
            <option value="null">All..</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->naziv); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <hr>
        <p class="hint-text">Choose manufacturer:</p>
        <select class="form-control" name="manufacturer_id">
            <option value="null">All..</option>
            <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m->id); ?>"><?php echo e($m->naziv); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <hr>
        <p class="hint-text">Choose price range:</p>
        <div class="row">
            <div class="col-6">
                <input type="number" class="form-control" name="price_min" placeholder="min">
            </div>
            <div class="col-6">
                <input type="number" class="form-control" name="price_max" placeholder="max">
            </div>
        </div>
        <p></p>
        <p></p>
        <button class="btn btn-outline-info" type="submit" id="btnSort">Search</button>
    </form>
</div>
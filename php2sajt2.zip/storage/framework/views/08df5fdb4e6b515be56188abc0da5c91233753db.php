<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/comment/index.blade.php */ ?>
<?php $__env->startSection('main'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">
                        Manage Comments
                    </h3>
                    <?php if(session()->has('message')): ?>
                        <div class="container">
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        </div>
                        <?php session()->forget('message'); ?>
                    <?php endif; ?>
                    <ol class="breadcrumb">
                        <li class="active">
                            <a href="" data-toggle="modal" data-target="#adminCommentInsert"  class="btn btn-primary" >Add new comment</a>
                        </li>
                    </ol>
                    <div class="col-md-8">
                        <div id="odgovor"></div>
                        <table class="table table-striped table-condensed table-bordered tabe-responsive" style="font-size: 14px;">
                            <tr>
                                <th>Product_ID</th>
                                <th>Product Name</th>
                                <th>User Name</th>
                                <th>Comment</th>
                                <th>Delete</th>
                                <th>Update</th>
                            </tr>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($c->proizvod_id); ?>

                                </td>
                                <td>
                                    <?php echo e($c->naziv); ?>

                                </td>
                                <td>
                                    <?php echo e($c->ime.' '.$c->prezime); ?>

                                </td>
                                <td>
                                    <?php echo e($c->text); ?>

                                </td>
                                <td>
                                    <a href=""  class="adminDeleteComment btn btn-danger" data-id="<?php echo e($c->k_id); ?>">Delete</a>
                                </td>
                                <td>
                                    <a href="" data-id="<?php echo e($c->k_id); ?>" data-toggle="modal" data-target="#adminCommentUpdate" class="adminUpdateComment btn btn-success">Update</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <?php echo e($comments->links()); ?>

                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startComponent('admin.comment.insert_modal', ['products' => $products, 'users' => $users]); ?><?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('admin.comment.update_modal', ['products' => $products, 'users' => $users]); ?><?php echo $__env->renderComponent(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
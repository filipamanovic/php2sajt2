<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/pages/user.blade.php */ ?>
<?php $__env->startSection('content_left'); ?>
    <?php $__env->startComponent('front.components.insert_product', [
        'categories' => $categories,
        'manufacturers' => $manufacturers
    ]); ?> <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('front.components.update_product_modal'); ?> <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_right'); ?>
    <div class="col-lg-9" style="margin-top: -24px;">
        <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php
                $brojac = 0;
                foreach ($userProducts as $item):
                if ($brojac == 0):
                ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?=$brojac?>" class="active"></li>
                <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?=$brojac?>"></li>
                <?php
                endif;
                $brojac ++;
                endforeach;
                ?>
            </ol>
            <div class="carousel-inner" role="listbox">
                <?php
                $brojac2 = 0;
                foreach ($userProducts as $item):
                if($brojac2 == 0):
                ?>
                <div class="carousel-item active">
                    <img class="d-block img-fluid" src="<?php echo e(asset($item->src)); ?>" alt="First slide" style="height: 32vw; width: 100%;">
                </div>
                <?php else: ?>
                <div class="carousel-item">
                    <img class="img-fluid" src="<?php echo e(asset($item->src)); ?>" alt="Second slide" style="height: 32vw; width: 100%;">
                </div>
                <?php endif; $brojac2++; endforeach; ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <div class="row">
            <?php $__currentLoopData = $userProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->startComponent('front.components.userProduct', ['product' => $p]); ?> <?php echo $__env->renderComponent(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
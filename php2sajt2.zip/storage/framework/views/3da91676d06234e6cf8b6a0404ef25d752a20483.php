<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/layouts/front.blade.php */ ?>
<?php echo $__env->make('front.common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.common.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <?php echo $__env->yieldContent('content_left'); ?>
        <?php echo $__env->yieldContent('content_right'); ?>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('front.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/common/footer.blade.php */ ?>
<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>


<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin_script.js')); ?>"></script>

</body>

</html>
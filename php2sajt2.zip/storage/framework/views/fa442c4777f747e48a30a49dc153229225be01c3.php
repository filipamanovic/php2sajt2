<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/role/index.blade.php */ ?>
<?php $__env->startSection('main'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">
                        Manage Role
                    </h3>
                    <?php if(session()->has('message')): ?>
                        <div class="container">
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        </div>
                        <?php session()->forget('message'); ?>
                    <?php endif; ?>
                    <ol class="breadcrumb">
                        <li class="active">
                            <a href="" data-toggle="modal" data-target="#adminRoleInsert"  class="btn btn-primary" >Add new role</a>
                        </li>
                    </ol>
                    <div class="col-md-8">
                        <div id="odgovor"></div>
                        <table class="table table-striped table-condensed table-bordered tabe-responsive" style="font-size: 14px;">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Delete</th>
                                <th>Update</th>
                            </tr>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($role->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($role->uloga); ?>

                                    </td>
                                    <td>
                                        <a href=""  class="adminDeleteUser btn btn-danger" data-id="">Delete</a>
                                    </td>
                                    <td>
                                        <a href="" data-id="" data-toggle="modal" data-target="#adminRoleUpdate" class="adminUpdateUser btn btn-success">Update</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <?php echo e($roles->links()); ?>

                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startComponent('admin.role.insert_modal'); ?><?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('admin.role.update_modal'); ?><?php echo $__env->renderComponent(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
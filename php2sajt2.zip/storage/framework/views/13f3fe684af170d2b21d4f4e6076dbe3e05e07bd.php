<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/components/userProduct.blade.php */ ?>
<div class="col-lg-4 col-md-6 mb-4">
    <div class="card h-100">
            <img class="card-img-top" style="height: 160px;" src="<?php echo e(asset($product->src)); ?>" alt="<?php echo e($product->alt); ?>">
        <div class="card-body">
            <h4 class="card-title" style="color: #138496;">
                 <?php echo e($product->naziv); ?>

            </h4>

            <h5 style="color: #138496;">&euro;<?php echo e($product->cena); ?></h5>
            <p class="card-text"><?php echo e($product->opis); ?></p>
        </div>
        <div class="card-footer">
            <button class="btn btn-outline-warning updateAd" data-id="<?php echo e($product->p_id); ?>" data-id2="<?php echo e($product->id); ?>" data-toggle="modal" data-target="#exampleModal">Update</button>
            <a class="btn btn-outline-danger deleteAd" href="<?php echo e(route('user', ['user'=> session()->get('user')->id])); ?>" data-id="<?php echo e($product->p_id); ?>">Delete</a>
        </div>
    </div>
</div>


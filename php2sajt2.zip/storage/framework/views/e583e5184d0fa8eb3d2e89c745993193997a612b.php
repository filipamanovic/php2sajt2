<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/comment/update_modal.blade.php */ ?>
<div class="modal fade" id="adminCommentUpdate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">Update comment</h3>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('commnet_update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <p></p>
                    <div class="form-group">
                        <label>Comment text</label>
                        <textarea rows="6" type="text" class="form-control" name="comment_text" id="comment_text" required="required"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Choose product</label>
                        <select name="product_id" class="form-control" id="adminProductddl">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->naziv); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Choose user</label>
                        <select name="user_id" class="form-control" id="adminUserddl">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->ime.' '.$user->prezime.' - '.$user->email); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <input type="hidden" id="comment_id" name="comment_id">
                    <div class="form-group">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success" name="inComm">Update user</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
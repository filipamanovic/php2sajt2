<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/front/components/product.blade.php */ ?>

    <div class="col-lg-4 col-md-6 mb-4">
        <div class="card h-100">
            <a class="viewsUpdate" data-id="<?php echo e($product->p_id); ?>" href="<?php echo e(url('/product/'.$product->p_id)); ?>">
                <img class="card-img-top" style="height: 160px;" src="<?php echo e(asset($product->src)); ?>" alt="<?php echo e($product->alt); ?>">
            </a>
            <div class="card-body">
                <h4 class="card-title">
                    <a class="viewsUpdate" data-id="<?php echo e($product->p_id); ?>" href="<?php echo e(url('/product/'.$product->p_id)); ?>" style="text-decoration: none; color: #138496;"> <?php echo e($product->naziv); ?> </a>
                </h4>
                <input type="hidden" id="tokenViews" value="<?php echo e(csrf_token()); ?>">
                <h5 style="color: #138496;">&euro;<?php echo e($product->cena); ?></h5>
                <p class="card-text"><?php echo e($product->opis); ?></p>
            </div>
        </div>
    </div>

<?php /* C:\Users\fica\Desktop\Projekti\web\php2sajt2\resources\views/admin/user/index.blade.php */ ?>
<?php $__env->startSection('main'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">
                        Manage Users
                    </h3>
                    <?php if(session()->has('message')): ?>
                        <div class="container">
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        </div>
                        <?php session()->forget('message'); ?>
                    <?php endif; ?>
                    <ol class="breadcrumb">
                        <li class="active">
                            <a href="" data-toggle="modal" data-target="#exampleModal4"  class="btn btn-primary" >Add new user</a>
                        </li>
                    </ol>
                    <div class="col-md-8">
                        <div id="odgovor"></div>
                        <table class="table table-striped table-condensed table-bordered tabe-responsive" style="font-size: 14px;">
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Contact</th>
                                <th>City</th>
                                <th>Active</th>
                                <th>Role</th>
                                <th>Delete</th>
                                <th>Update</th>
                            </tr>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($user->id); ?>

                                </td>
                                <td>
                                    <?php echo e($user->ime); ?>

                                </td>
                                <td>
                                    <?php echo e($user->prezime); ?>

                                </td>
                                <td>
                                    <?php echo e($user->email); ?>

                                </td>
                                <td>
                                    <?php echo e($user->kontakt); ?>

                                </td>
                                <td>
                                    <?php echo e($user->grad); ?>

                                </td>
                                <td>
                                    <?php echo e($user->aktivan); ?>

                                </td>
                                <td>
                                    <?php echo e($user->uloga); ?>

                                </td>
                                <td>
                                    <a href=""  class="adminDeleteUser btn btn-danger" data-id="<?php echo e($user->id); ?>">Delete</a>
                                </td>
                                <td>
                                    <a href="" data-id="<?php echo e($user->id); ?>" data-toggle="modal" data-target="#adminUserUpdate" class="adminUpdateUser btn btn-success">Update</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <?php echo e($users->links()); ?>

                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startComponent('admin.user.insert_modal', ['roles' => $roles]); ?><?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('admin.user.update_modal', ['roles' => $roles]); ?><?php echo $__env->renderComponent(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
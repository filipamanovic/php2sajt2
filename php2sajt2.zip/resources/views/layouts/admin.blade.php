@include('admin.common.head')
<div id="wrapper">
    @include('admin.common.nav')
    @yield('main')
</div>
@include('admin.common.footer')

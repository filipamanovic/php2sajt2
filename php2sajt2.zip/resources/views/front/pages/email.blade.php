Hi <strong>{{ $name }}</strong>,

<p> Please verify your account by clicking on this liknk:</p>
<a href="{{$body}}">Click Me!</a>
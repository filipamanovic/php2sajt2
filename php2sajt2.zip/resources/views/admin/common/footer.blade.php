<!-- jQuery -->
<script src="{{asset('js/jquery.js')}}"></script>


<!-- Bootstrap Core JavaScript -->
<script src="{{asset('js/bootstrap.js')}}"></script>
<script src="{{ asset('js/admin_script.js') }}"></script>

</body>

</html>